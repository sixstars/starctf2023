generate your own flag file, verify using `file` command like this:

$ file -m flag.mgc flag
flag: yes, it's a flag!



$ file --version
file-5.41
magic file from /usr/share/file/magic

